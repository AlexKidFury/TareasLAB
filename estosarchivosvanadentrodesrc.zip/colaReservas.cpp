#include "../include/colaReservas.h"

struct rep_colaReservas {
};

TColaReservas crearTColaReservas(){
  return NULL;
}

void encolarTColaReservas(TColaReservas &colaReservas, TReserva reserva){
}

void desencolarTColaReservas(TColaReservas &colaReservas) {
}

TReserva frenteTColaReservas(TColaReservas colaReservas) {
    return NULL;
}

nat cantidadTColaReservas(TColaReservas colaReservas){
    return 0;
}

void imprimirTColaReservas(TColaReservas colaReservas){
}

void liberarTColaReservas(TColaReservas &colaReservas){
}

TReserva extraerFrenteTColaReservas(TColaReservas &colaReservas) {
  return NULL;
}
